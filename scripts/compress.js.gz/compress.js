#!/usr/bin/env node

/**
 * 静态资源压缩脚本
 * 功能：
 * 1. 为所有静态资源生成 .gz (gzip) 和 .br (brotli) 压缩版本
 * 2. 生成压缩统计报告
 * 3. 适用于 GitHub Pages 部署（自动检测压缩文件）
 */

import { promises as fs } from 'fs';
import { join } from 'path';
import { createReadStream, createWriteStream } from 'fs';
import { pipeline } from 'stream/promises';
import { gzip, brotliCompress } from 'zlib';
import { promisify } from 'util';

const gzipAsync = promisify(gzip);
const brotliCompressAsync = promisify(brotliCompress);

const BUILD_DIR = new URL('.', import.meta.url).pathname;
const ASSETS_DIR = join(BUILD_DIR, 'assets');

// 需要压缩的文件类型
const ASSET_PATTERNS = [
  '*.js',
  '*.css',
  '*.html',
  '*.json',
  '*.svg'
];

// 忽略的文件
const IGNORE_PATTERNS = [
  'node_modules/**',
  'tests/**',
  '*.test.js',
  'vite.config.js',
  'package*.json',
  '*.gz',
  '*.br',
  'scripts/**' // 忽略脚本目录
];

/**
 * 获取所有需要压缩的文件
 */
async function getFilesToCompress() {
  const files = [];
  
  for (const pattern of ASSET_PATTERNS) {
    const { glob } = await import('glob');
    const matches = await glob(pattern, {
      cwd: BUILD_DIR,
      ignore: IGNORE_PATTERNS,
      nodir: true
    });
    files.push(...matches);
  }
  
  return files;
}

/**
 * Gzip 压缩单个文件
 */
async function compressGzip(inputPath, outputPath) {
  const input = await fs.readFile(inputPath);
  const compressed = await gzipAsync(input, { level: 9 });
  await fs.writeFile(outputPath, compressed);
  
  const original = input.length;
  const result = compressed.length;
  
  return {
    original,
    compressed: result,
    ratio: ((1 - result / original) * 100).toFixed(2)
  };
}

/**
 * Brotli 压缩单个文件
 */
async function compressBrotli(inputPath, outputPath) {
  const input = await fs.readFile(inputPath);
  const compressed = await brotliCompressAsync(input, {
    params: {
      [brotliCompress.constants.BROTLI_PARAM_QUALITY]: 11
    }
  });
  await fs.writeFile(outputPath, compressed);
  
  const original = input.length;
  const result = compressed.length;
  
  return {
    original,
    compressed: result,
    ratio: ((1 - result / original) * 100).toFixed(2)
  };
}

/**
 * 压缩单个文件（生成 gzip 和 brotli 两种格式）
 */
async function compressFile(filePath) {
  const inputPath = join(BUILD_DIR, filePath);
  
  try {
    const [gzipStats, brotliStats] = await Promise.all([
      compressGzip(inputPath, inputPath + '.gz'),
      compressBrotli(inputPath, inputPath + '.br')
    ]);
    
    return {
      file: filePath,
      original: gzipStats.original,
      gzip: gzipStats,
      brotli: brotliStats
    };
  } catch (error) {
    console.error(`Error compressing ${filePath}:`, error.message);
    return null;
  }
}

/**
 * 格式化字节数
 */
function formatBytes(bytes) {
  const units = ['B', 'KB', 'MB'];
  let unitIndex = 0;
  let size = bytes;
  
  while (size >= 1024 && unitIndex < units.length - 1) {
    size /= 1024;
    unitIndex++;
  }
  
  return `${size.toFixed(2)} ${units[unitIndex]}`;
}

/**
 * 主函数
 */
async function main() {
  console.log('🔍  scanning files...\n');
  
  const files = await getFilesToCompress();
  
  if (files.length === 0) {
    console.log('No files to compress.');
    return;
  }
  
  console.log(`📦 Found ${files.length} files to compress:\n`);
  files.forEach(f => console.log(`   - ${f}`));
  console.log();
  
  console.log('🗜️  compressing...\n');
  
  const results = [];
  let totalOriginal = 0;
  let totalGzip = 0;
  let totalBrotli = 0;
  
  for (const file of files) {
    process.stdout.write(`   ${file}... `);
    const result = await compressFile(file);
    
    if (result) {
      results.push(result);
      totalOriginal += result.original;
      totalGzip += parseInt(result.gzip.compressed);
      totalBrotli += parseInt(result.brotli.compressed);
      
      console.log(`✓ gzip: ${result.gzip.ratio}% | brotli: ${result.brotli.ratio}%`);
    }
  }
  
  // 输出统计报告
  console.log('\n📊 Compression Report:\n');
  console.log('┌─────────────────────────────────┬────────────┬────────────┬────────────┐');
  console.log('│ File                            │  Original  │   Gzip     │   Brotli   │');
  console.log('├─────────────────────────────────┼────────────┼────────────┼────────────┤');
  
  for (const r of results) {
    const filename = r.file.length > 31 ? '...' + r.file.slice(-28) : r.file;
    console.log(
      `│ ${filename.padEnd(31)} │ ${formatBytes(r.original).padStart(10)} │ ${formatBytes(parseInt(r.gzip.compressed)).padStart(10)} │ ${formatBytes(parseInt(r.brotli.compressed)).padStart(10)} │`
    );
  }
  
  console.log('├─────────────────────────────────┼────────────┼────────────┼────────────┤');
  console.log(
    `│ ${'TOTAL'.padEnd(31)} │ ${formatBytes(totalOriginal).padStart(10)} │ ${formatBytes(totalGzip).padStart(10)} │ ${formatBytes(totalBrotli).padStart(10)} │`
  );
  console.log('└─────────────────────────────────┴────────────┴────────────┴────────────┘');
  
  const gzipSavings = ((1 - totalGzip / totalOriginal) * 100).toFixed(2);
  const brotliSavings = ((1 - totalBrotli / totalOriginal) * 100).toFixed(2);
  
  console.log(`\n💡 Savings: Gzip ${gzipSavings}% | Brotli ${brotliSavings}%`);
  console.log('\n✅ Compression complete!\n');
  console.log('📝 Note: GitHub Pages will automatically serve compressed files based on Accept-Encoding header.\n');
}

// 运行脚本
main().catch(console.error);
