/**
 * 轻量级错误监控模块
 * 功能：
 * 1. 捕获 JavaScript 错误
 * 2. 捕获未处理的 Promise 拒绝
 * 3. 捕获资源加载错误
 * 4. 记录错误上下文（URL、用户代理、时间戳）
 * 5. 本地存储错误日志（最多保留 50 条）
 */
(function() {

const ERROR_STORE_KEY = 'app_error_logs';
const MAX_ERROR_LOGS = 50;

/**
 * 错误监控配置
 */
const config = {
  enabled: true,
  maxErrors: MAX_ERROR_LOGS,
  environment: window.location.hostname.includes('localhost') ? 'development' : 'production'
};

/**
 * 存储错误日志
 */
function storeError(errorLog) {
  try {
    const existing = JSON.parse(localStorage.getItem(ERROR_STORE_KEY) || '[]');
    existing.unshift(errorLog); // 新错误放在前面
    
    // 限制存储数量
    if (existing.length > config.maxErrors) {
      existing.splice(config.maxErrors);
    }
    
    localStorage.setItem(ERROR_STORE_KEY, JSON.stringify(existing));
  } catch (e) {
    console.error('[ErrorMonitor] Failed to store error:', e);
  }
}

/**
 * 获取错误日志
 */
window.getErrorLogs = function getErrorLogs() {
  try {
    return JSON.parse(localStorage.getItem(ERROR_STORE_KEY) || '[]');
  } catch (e) {
    return [];
  }
}

/**
 * 清除错误日志
 */
window.clearErrorLogs = function clearErrorLogs() {
  localStorage.removeItem(ERROR_STORE_KEY);
}

/**
 * 导出错误日志为 JSON 文件
 */
window.exportErrorLogs = function exportErrorLogs() {
  const logs = getErrorLogs();
  const blob = new Blob([JSON.stringify(logs, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `error-logs-${new Date().toISOString().split('T')[0]}.json`;
  a.click();
  URL.revokeObjectURL(url);
}

/**
 * 创建错误日志对象
 */
function createErrorLog(error, type, context = {}) {
  return {
    timestamp: new Date().toISOString(),
    type: type, // 'js-error' | 'promise-rejection' | 'resource-error'
    message: error?.message || String(error),
    stack: error?.stack || null,
    url: window.location.href,
    userAgent: navigator.userAgent,
    environment: config.environment,
    context: context
  };
}

/**
 * 处理 JavaScript 错误
 */
function handleJsError(event) {
  if (!config.enabled) return;
  
  event.preventDefault(); // 阻止默认错误输出
  
  const errorLog = createErrorLog(event.error, 'js-error', {
    filename: event.filename,
    lineno: event.lineno,
    colno: event.colno
  });
  
  storeError(errorLog);
  console.error('[ErrorMonitor] Caught error:', errorLog);
}

/**
 * 处理未处理的 Promise 拒绝
 */
function handleUnhandledRejection(event) {
  if (!config.enabled) return;
  
  event.preventDefault();
  
  const errorLog = createErrorLog(event.reason, 'promise-rejection', {
    reason: event.reason?.toString()
  });
  
  storeError(errorLog);
  console.error('[ErrorMonitor] Unhandled rejection:', errorLog);
}

/**
 * 处理资源加载错误
 */
function handleResourceError(event) {
  if (!config.enabled) return;
  
  const target = event.target || event.srcElement;
  const errorLog = createErrorLog(
    `Failed to load resource: ${target?.tagName || 'unknown'}`,
    'resource-error',
    {
      tagName: target?.tagName,
      src: target?.src || target?.href,
      id: target?.id
    }
  );
  
  storeError(errorLog);
  console.error('[ErrorMonitor] Resource error:', errorLog);
}

/**
 * 初始化错误监控
 */
window.initErrorMonitor = function initErrorMonitor() {
  if (!config.enabled) {
    console.log('[ErrorMonitor] Disabled');
    return;
  }
  
  // 全局错误监听
  window.addEventListener('error', handleJsError);
  window.addEventListener('unhandledrejection', handleUnhandledRejection);
  
  // 资源错误监听（捕获阶段）
  window.addEventListener('error', handleResourceError, true);
  
  // 监听 Storage 事件（多标签页同步）
  window.addEventListener('storage', (e) => {
    if (e.key === ERROR_STORE_KEY) {
      console.log('[ErrorMonitor] Error logs updated in another tab');
    }
  });
  
  console.log('[ErrorMonitor] Initialized in', config.environment, 'mode');
  
  // 返回 API 对象
  return {
    getErrorLogs,
    clearErrorLogs,
    exportErrorLogs,
    enable: () => { config.enabled = true; },
    disable: () => { config.enabled = false; }
  };
}

// 自动初始化
window.errorMonitor = initErrorMonitor();

})();
