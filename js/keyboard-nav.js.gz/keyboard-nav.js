/**
 * 键盘导航模块
 * 功能：
 * 1. Tab 键导航支持
 * 2. 焦点管理（Focus Management）
 * 3. 键盘快捷键
 * 4. WCAG 2.1 对比度验证
 */
(function() {

// 键盘导航配置
const config = {
  enabled: true,
  focusOutlineColor: '#007aff',
  focusOutlineWidth: '2px'
};

/**
 * 初始化键盘导航
 */
function initKeyboardNavigation() {
  if (!config.enabled) return;
  
  // 添加焦点可见样式
  addFocusStyles();
  
  // 键盘快捷键
  document.addEventListener('keydown', handleKeyDown);
  
  // 焦点追踪
  setupFocusTracking();
  
  console.log('[KeyboardNav] Initialized');
}

/**
 * 添加焦点样式
 */
function addFocusStyles() {
  const style = document.createElement('style');
  style.textContent = `
    /* 全局焦点样式 */
    *:focus {
      outline: ${config.focusOutlineWidth} solid ${config.focusOutlineColor};
      outline-offset: 2px;
    }
    
    /* 按钮焦点 */
    button:focus, .btn:focus {
      outline: ${config.focusOutlineWidth} solid ${config.focusOutlineColor};
      outline-offset: 2px;
      box-shadow: 0 0 0 4px rgba(0, 122, 255, 0.3);
    }
    
    /* 卡片焦点 */
    .book-card:focus, .unit-card:focus {
      outline: ${config.focusOutlineWidth} solid ${config.focusOutlineColor};
      outline-offset: 4px;
    }
    
    /* 输入框焦点 */
    input:focus, select:focus, textarea:focus {
      outline: ${config.focusOutlineWidth} solid ${config.focusOutlineColor};
      border-color: ${config.focusOutlineColor};
    }
    
    /* 高对比度模式 */
    @media (prefers-contrast: more) {
      *:focus {
        outline: 3px solid currentColor;
        outline-offset: 2px;
      }
    }
    
    /* 减少动画模式 */
    @media (prefers-reduced-motion: reduce) {
      *, *::before, *::after {
        animation-duration: 0.01ms !important;
        animation-iteration-count: 1 !important;
        transition-duration: 0.01ms !important;
      }
    }
  `;
  document.head.appendChild(style);
}

/**
 * 键盘快捷键处理
 */
function handleKeyDown(e) {
  // 如果在输入框中，不处理快捷键
  if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') {
    return;
  }
  
  const shortcuts = {
    // 空格键：播放/暂停
    ' ': () => {
      const playBtn = document.getElementById('playBtn');
      if (playBtn) playBtn.click();
      e.preventDefault();
    },
    
    // 左箭头：上一课
    'ArrowLeft': () => {
      const prevBtn = document.getElementById('prevBtn');
      if (prevBtn && !prevBtn.disabled) prevBtn.click();
      e.preventDefault();
    },
    
    // 右箭头：下一课
    'ArrowRight': () => {
      const nextBtn = document.getElementById('nextBtn');
      if (nextBtn && !nextBtn.disabled) nextBtn.click();
      e.preventDefault();
    },
    
    // L：切换歌词显示模式
    'l': () => {
      const transBtn = document.getElementById('transBtn');
      if (transBtn) transBtn.click();
      e.preventDefault();
    },
    
    // S：切换速度
    's': () => {
      const speedBtn = document.getElementById('speedBtn');
      if (speedBtn) speedBtn.click();
      e.preventDefault();
    },
    
    // R：切换重复模式
    'r': () => {
      const modeBtn = document.getElementById('modeBtn');
      if (modeBtn) modeBtn.click();
      e.preventDefault();
    },
    
    // F：添加/移除收藏
    'f': () => {
      const favBtn = document.getElementById('addToFav');
      if (favBtn) favBtn.click();
      e.preventDefault();
    },
    
    // /：搜索（未来功能）
    '/': () => {
      // TODO: 打开搜索框
      e.preventDefault();
    },
    
    // ?: 显示快捷键帮助
    '?': () => {
      showKeyboardShortcutsHelp();
      e.preventDefault();
    }
  };
  
  const handler = shortcuts[e.key];
  if (handler) {
    handler();
  }
}

/**
 * 显示快捷键帮助
 */
function showKeyboardShortcutsHelp() {
  const shortcuts = [
    { key: '空格', action: '播放/暂停' },
    { key: '←', action: '上一课' },
    { key: '→', action: '下一课' },
    { key: 'L', action: '切换歌词显示' },
    { key: 'S', action: '切换速度' },
    { key: 'R', action: '切换模式' },
    { key: 'F', action: '收藏句子' },
    { key: '?', action: '显示帮助' }
  ];
  
  const html = `
    <div class="keyboard-help-modal" style="
      position: fixed;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      background: white;
      padding: 24px;
      border-radius: 12px;
      box-shadow: 0 4px 24px rgba(0,0,0,0.2);
      z-index: 10000;
      max-width: 400px;
      width: 90%;
    ">
      <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px;">
        <h3 style="margin: 0;">⌨️ 快捷键</h3>
        <button id="closeKeyboardHelp" style="
          background: none;
          border: none;
          font-size: 24px;
          cursor: pointer;
          padding: 4px;
          line-height: 1;
        ">&times;</button>
      </div>
      <div style="display: grid; grid-template-columns: 1fr 2fr; gap: 12px;">
        ${shortcuts.map(s => `
          <div style="padding: 8px; background: #f5f5f5; border-radius: 6px; text-align: center; font-weight: bold;">
            ${s.key}
          </div>
          <div style="padding: 8px; display: flex; align-items: center;">
            ${s.action}
          </div>
        `).join('')}
      </div>
      <p style="margin-top: 16px; color: #666; font-size: 14px; text-align: center;">
        按 ? 键关闭此帮助
      </p>
    </div>
  `;
  
  const modal = document.createElement('div');
  modal.innerHTML = html;
  document.body.appendChild(modal);
  
  // 关闭按钮
  modal.querySelector('#closeKeyboardHelp').addEventListener('click', () => {
    modal.remove();
  });
  
  // ESC 关闭
  const escHandler = (e) => {
    if (e.key === 'Escape') {
      modal.remove();
      document.removeEventListener('keydown', escHandler);
    }
  };
  document.addEventListener('keydown', escHandler);
}

/**
 * 焦点追踪
 */
function setupFocusTracking() {
  document.addEventListener('focusin', (e) => {
    const target = e.target;
    
    // 为焦点元素添加标记
    target.setAttribute('data-focused', 'true');
    
    // 滚动到可视区域（如果需要）
    if (target.scrollIntoViewIfNeeded) {
      target.scrollIntoViewIfNeeded({ behavior: 'smooth', block: 'nearest' });
    }
  });
  
  document.addEventListener('focusout', (e) => {
    e.target.removeAttribute('data-focused');
  });
}

/**
 * 验证 WCAG 对比度
 */
function checkContrastRatio() {
  const colors = [
    { fg: '#000000', bg: '#FFFFFF', min: 4.5 },  // 正常文本
    { fg: '#666666', bg: '#FFFFFF', min: 4.5 },  // 次要文本
    { fg: '#007AFF', bg: '#FFFFFF', min: 3.0 },  // 链接/按钮
    { fg: '#FFFFFF', bg: '#007AFF', min: 4.5 },  // 按钮文字
    { fg: '#FF3B30', bg: '#FFFFFF', min: 4.5 },  // 危险操作
    { fg: '#34C759', bg: '#FFFFFF', min: 4.5 },  // 成功状态
  ];
  
  const results = colors.map(c => {
    const ratio = calculateContrastRatio(c.fg, c.bg);
    return {
      foreground: c.fg,
      background: c.bg,
      ratio: ratio.toFixed(2),
      pass: ratio >= c.min,
      requirement: c.min
    };
  });
  
  console.table(results);
  return results;
}

/**
 * 计算对比度比率
 */
function calculateContrastRatio(fg, bg) {
  const luminance1 = getLuminance(hexToRgb(fg));
  const luminance2 = getLuminance(hexToRgb(bg));
  
  const lighter = Math.max(luminance1, luminance2);
  const darker = Math.min(luminance1, luminance2);
  
  return (lighter + 0.05) / (darker + 0.05);
}

/**
 * 计算相对亮度
 */
function getLuminance(rgb) {
  const channels = [rgb.r, rgb.g, rgb.b].map(channel => {
    channel = channel / 255;
    return channel <= 0.03928
      ? channel / 12.92
      : Math.pow((channel + 0.055) / 1.055, 2.4);
  });
  
  return 0.2126 * channels[0] + 0.7152 * channels[1] + 0.0722 * channels[2];
}

/**
 * Hex 转 RGB
 */
function hexToRgb(hex) {
  const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
  return result ? {
    r: parseInt(result[1], 16),
    g: parseInt(result[2], 16),
    b: parseInt(result[3], 16)
  } : { r: 0, g: 0, b: 0 };
}

// 自动初始化
initKeyboardNavigation();

// 导出 API
window.keyboardNav = {
  initKeyboardNavigation,
  checkContrastRatio,
  showKeyboardShortcutsHelp
};

})();
