/**
 * 可测试的模块 - 从 main.js 导出纯函数
 */

// 从 main.js 复制纯函数（不依赖 DOM 的函数）
export const SPEEDS = [0.5, 0.75, 1.0, 1.25, 1.5, 2.0];
export const REPEAT_COUNTS = [1, 2, 3, 5, 10, 99];

export const LS = { 
  BOOK: 'nce_book', 
  UNIT: k => `nce_${k}_u`, 
  TIME: (k,u) => `nce_${k}_${u}_t`, 
  SPD: 'nce_spd', 
  MODE: 'nce_mode', 
  TR: 'nce_tr',
  LAST_PAGE: 'nce_last_page',
  FAVORITES: 'nce_favorites',
  REPEAT: 'nce_repeat',
  USER_PROFILE: 'nce_user_profile',
  LEARNING_STATS: 'nce_learning_stats',
  PROGRESS: 'nce_progress',
  SELECTED_COURSES: 'nce_selected_courses'
};

export const AUDIO_SOURCE = 'supabase';
export const SUPABASE_URL = 'https://jikhdympaifsmubmwilp.supabase.co';
export const SUPABASE_BUCKETS = {
  NCE1: 'nce1-audio',
  THINK_0: 'think0-audio',
  THINK_F: 'think0-audio'
};

export function formatLearningTime(minutes) {
  if (!minutes || minutes < 60) {
    return (minutes || 0) + 'm';
  }
  const hours = Math.floor(minutes / 60);
  const mins = Math.round(minutes % 60);
  return hours + 'h' + (mins > 0 ? mins + 'm' : '');
}

export function getFavorites() {
  try {
    return JSON.parse(localStorage.getItem('nce_favorites') || '[]');
  } catch {
    return [];
  }
}

export function loadLearningStats() {
  const stats = JSON.parse(localStorage.getItem('nce_learning_stats') || '{}');
  return {
    totalTime: stats.totalTime || 0,
    streak: stats.streak || 0,
    lastStudyDate: stats.lastStudyDate || null
  };
}

export function calculateVisibleItems(itemHeight, viewportHeight) {
  return Math.ceil(viewportHeight / itemHeight) + 4;
}

export function calculateStartIndex(scrollTop, itemHeight) {
  return Math.max(0, Math.floor(scrollTop / itemHeight) - 2);
}
